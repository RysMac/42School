// this contains
// camera, Lights, Objects[] + count, Ambient

typedef struct s_camera
{
    int w;
    int h;
    double fovx;
    double fovy;
    double c[3]; // camera center
    double f[3]; // forward direction
    double r[3]; // right
    double u[3]; // up
} t_camera;