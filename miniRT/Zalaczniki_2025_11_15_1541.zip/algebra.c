#include <math.h>

double vnorm3(const double v[3])
{
    return sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
}

void vnormalize3(const double v[3], double vnrm[3])
{
    double nrm;

    nrm = vnorm3(v);
    if (nrm == 0.0)
    {
        vnrm[0] = vnrm[1] = vnrm[2] = 0.0;
        return ;
    }
    vnrm[0] = v[0] / nrm;
    vnrm[1] = v[1] / nrm;
    vnrm[2] = v[2] / nrm; 
}

void cross3(const double a[3], const double b[3], double result[3])
{
    result[0] = a[1]*b[2] - a[2]*b[1];
    result[1] = a[2]*b[0] - a[0]*b[2];
    result[2] = a[0]*b[1] - a[1]*b[0];
}