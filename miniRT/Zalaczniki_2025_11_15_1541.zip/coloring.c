#include "framebuffer.h"

// fill fb->data
void    fill_gradient(t_framebuffer *fb)
{
    size_t w = fb->w;
    size_t h = fb->h;
    size_t x = 0;
    size_t y = 0;

    while (y < h)
    {
		// safeguard [0,1]
		double gy = (h > 1) ? (1.0 - (double)y / (double)(h - 1)) : 0.0;
        double G = pow(gy, 1.0/2.2);
        x = 0;
        while (x < w)
        {
			// safeguard [0,1]
			double rx = (w > 1) ? (double)(x * y/3) / (double)(w - 1) : 0.0;
            double R = pow(rx, 1.0/2.2);
            double B = 0.0;            
            
			size_t idx = (y * w + x) * 3;
            fb->data[idx+0] = (uint8_t)lrint(255.0 * R);
            fb->data[idx+1] = (uint8_t)lrint(255.0 * G);
            fb->data[idx+2] = (uint8_t)lrint(255.0 * B);
			x++;
        }
		y++;
    }   
}

// testing directions and rays
void fill_direction_debug(t_framebuffer *fb, const t_camera *cam)
{
    size_t w = fb->w;
    size_t h = fb->h;

    for (size_t y = 0; y < h; ++y) {
        for (size_t x = 0; x < w; ++x) {
            double d[3];
            d_ij(cam, (int)x, (int)y, d);  // direction, SHOULD be normalized

            // d is in roughly [-1,1] for each component
            double R = 0.5 * (d[0] + 1.0);  // map [-1,1] -> [0,1]
            double G = 0.5 * (d[1] + 1.0);
            double B = 0.5 * (d[2] + 1.0);

            // clamp to [0,1] just in case of numerical noise
            if (R < 0.0) R = 0.0; if (R > 1.0) R = 1.0;
            if (G < 0.0) G = 0.0; if (G > 1.0) G = 1.0;
            if (B < 0.0) B = 0.0; if (B > 1.0) B = 1.0;

            size_t idx = (y * w + x) * 3;
            fb->data[idx+0] = (uint8_t)lrint(255.0 * R);
            fb->data[idx+1] = (uint8_t)lrint(255.0 * G);
            fb->data[idx+2] = (uint8_t)lrint(255.0 * B);
        }
    }
}


// INSANE VIEW:
// Ray: origin o[3], dir d[3] (normalized)
// Plane: y = y_plane
// Return 1 if hit with t>0, store t in *t_out
static int ray_plane_y(const double o[3], const double d[3],
                       double y_plane, double *t_out)
{
    double denom = d[1]; // dot(d, (0,1,0))

    // parallel or almost: no hit
    if (fabs(denom) < 1e-6)
        return 0;

    double t = (y_plane - o[1]) / denom;
    if (t <= 0.0)
        return 0;

    *t_out = t;
    return 1;
}

void render_insane_view(t_framebuffer *fb, const t_camera *cam)
{
    size_t w = fb->w;
    size_t h = fb->h;

    for (size_t y = 0; y < h; ++y) {
        for (size_t x = 0; x < w; ++x) {
            double d[3];
            d_ij(cam, (int)x, (int)y, d);  // normalized direction

            double R, G, B;

            double t;
            if (ray_plane_y(cam->c, d, -1.0, &t)) {
                // Hit the ground plane at y=-1
                double p[3];
                p[0] = cam->c[0] + t * d[0];
                p[1] = cam->c[1] + t * d[1];
                p[2] = cam->c[2] + t * d[2];

                // Checker pattern in XZ
                int checker =
                    (((int)floor(p[0]) + (int)floor(p[2])) & 1);

                double base = checker ? 0.9 : 0.2; // light/dark tiles

                // Distance fade: closer bright, far darker
                double dist = t;
                double fade = 1.0 / (1.0 + 0.02 * dist * dist); // tweak factor

                double c = base * fade;

                R = c;
                G = c;
                B = c;
            } else {
                // Sky: simple vertical gradient based on d.y
                double tsky = 0.5 * (d[1] + 1.0); // [-1,1] -> [0,1]
                if (tsky < 0.0) tsky = 0.0;
                if (tsky > 1.0) tsky = 1.0;

                // dark blue at bottom, light at top
                R = 0.2 * tsky;
                G = 0.5 * tsky;
                B = 0.9 * tsky + 0.1 * (1.0 - tsky);
            }

            // optional "gamma"
            double gamma = 1.0 / 2.2;
            R = pow(R, gamma);
            G = pow(G, gamma);
            B = pow(B, gamma);

            // clamp
            if (R < 0.0) R = 0.0; if (R > 1.0) R = 1.0;
            if (G < 0.0) G = 0.0; if (G > 1.0) G = 1.0;
            if (B < 0.0) B = 0.0; if (B > 1.0) B = 1.0;

            size_t idx = (y * w + x) * 3;
            fb->data[idx+0] = (uint8_t)lrint(255.0 * R);
            fb->data[idx+1] = (uint8_t)lrint(255.0 * G);
            fb->data[idx+2] = (uint8_t)lrint(255.0 * B);
        }
    }
}

void setup_insane_camera(t_camera *cam, int w, int h)
{
    cam->w = w;
    cam->h = h;
    cam->fovx = 110.0; // wide as hell
    cam->fovy = 80.0;  // also wide

    // Camera at (0,0,0.5), looking slightly downward and forward
    cam->c[0] = 0.0;
    cam->c[1] = 0.0;
    cam->c[2] = 0.5;

    double f_raw[3] = {0.0, -0.3, 1.0}; // forward: down a bit + forward in z
    vnormalize3(f_raw, cam->f);

    const double up_world[3] = {0.0, 1.0, 0.0};

    // right = f x up
    cross3(cam->f, up_world, cam->r);
    vnormalize3(cam->r, cam->r);

    // recompute true up = r x f
    cross3(cam->r, cam->f, cam->u);
    vnormalize3(cam->u, cam->u);
}
