// object type
typedef enum s_obj_type
{
    OBJ_SPHERE,
    OBJ_PLANE,
    OBJ_CYLINDER,
    OBJ_CONE,        // optional future
    OBJ_ELLIPSOID,   // optional future
    OBJ_INVALID      // optional sentinel
}	t_obj_type;

// object position/orientation in global frame
// for sphere the origin, for plane normal etc
typedef struct s_obj_pos
{
    double  pos[3];   // position in the world space
    double  dir[3];   // orinetation axis / normal (unit ector)
}   t_obj_pos;

// plane needs nothing
// sphere -> needs radius info
typedef struct s_sphere
{
	double	radius;
}	t_sphere;

// cylinder -> needs axis
typedef struct s_cylinder
{
	double	radius;
	double	height;
}	t_cylinder;

// generic shape data: tagged by t_obj_type
typedef union u_shape_data
{
    t_sphere    sphere;
    t_cylinder  cylinder;
    // add cone, ellipsoid, ... later
}   t_shape_data;

// whole object info
typedef struct s_obj
{
    t_obj_type		type;
    t_obj_pos		pos;
    t_shape_data	shape;// others later

}   t_obj;