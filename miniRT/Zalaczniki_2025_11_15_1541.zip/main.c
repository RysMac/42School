#include <stdlib.h>
#include <stdio.h>
#include "framebuffer.h"

double print_vector3(const double v[3])
{
    for (int i = 0; i < 3; i++)
        printf(" %f ", v[i]);
    printf("\n");
}

int main()
{
    const size_t w = 800;
    const size_t h = 800;
    const double f_in[3] = { 0.0, 0.0, 1.0 };
    const double c[3] = { 0.0, 0.0, 0.0 };
    double fovx = 90;

    t_framebuffer   fb;
    t_camera        camera;

    if (fb_init(&fb, w, h))
        return (1);

    // fill_gradient(&fb);

    camera_set(&camera, w, h, fovx, f_in, c);

    print_vector3(camera.f);
    print_vector3(camera.u);
    printf("FOV y = %f \n", camera.fovy);

    double rij[3];
    r_ij(&camera, 1, 1, 1., rij);
    print_vector3(rij);

    // fill_direction_debug(&fb, &camera);
    setup_insane_camera(&camera, fb.w, fb.h);

    render_insane_view(&fb, &camera);

    const char *path = "view.ppm";
    if (ppm_write(path, &fb) == 1)
        printf("wrong ppm_write\n");
    printf("end of program \n");
    return (0);
}