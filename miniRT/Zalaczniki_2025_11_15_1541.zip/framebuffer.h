#ifndef FRAMEBUFFER_H
# define FRAMEBUFFER_H

# include <stddef.h>
# include <stdint.h>
# include <math.h>
# include "scene.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

typedef struct s_framebuffer
{
    size_t w; // width
	size_t h; // height
    uint8_t *data; // the whole array of pixels info

}	t_framebuffer;

// algebra.c vector operations
double	vnorm3(const double v[3]);
void	vnormalize3(const double v[3], double vnrm[3]);
void	cross3(const double a[3], const double b[3], double result[3]);

//*************** */

int		fb_init(t_framebuffer *fb, size_t w, size_t h);
void	fb_free(t_framebuffer *fb);
void	fill_gradient(t_framebuffer *fb);
int		ppm_write(const char *path, const t_framebuffer *fb);
void    camera_set(t_camera *camera, int w, int h, double fov, const double f_in[3], const double c[3]);
void    vnormalize3(const double v[3], double vnrm[3]);
void    d_ij(const t_camera *camera, int i, int j, double dij[3]); // to be deleted
void    r_ij(const t_camera *camera, int i, int j, double t, double rij[3]);
void    fill_direction_debug(t_framebuffer *fb, const t_camera *cam);
void    setup_insane_camera(t_camera *cam, int w, int h); // just to test rays direction
void    render_insane_view(t_framebuffer *fb, const t_camera *cam); // insane view

#endif